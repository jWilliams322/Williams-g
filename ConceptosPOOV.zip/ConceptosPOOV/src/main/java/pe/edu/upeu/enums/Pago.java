package pe.edu.upeu.enums;

enum TPO_PAGO{Efectivo, Credito, Tranferencia, Yape};

enum MES{Enero, Febrero,}


public class Pago {

    TPO_PAGO tipo;
    MES mes;
    double monto;
    String cuenta;
    double impuesto;


    public static void main(String[] args){
        Pago p=new Pago();
        p.tipo=TPO_PAGO.Efectivo;
        p.mes=MES.Enero;
        p.monto=100;
        p.cuenta="1435 5454 5454 5454";
        p.impuesto=10;

        System.out.println("Tipo de pago: "+p.tipo);
        System.out.println("Monto: "+p.monto);
        System.out.println("Cuenta: "+p.cuenta);
        System.out.println("Impuesto: "+p.impuesto);

        for ( TPO_PAGO t : TPO_PAGO.values()){
            System.out.println("Tipo de pago: "+t);
        }

    }



}
