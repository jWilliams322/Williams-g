package pe.edu.upeu.polimorfisma;

public class Gato extends Animal {

    @Override
    void sonidoAnimal() {
        System.out.println("Meu....mew...");
    }
}
