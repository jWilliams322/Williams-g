package pe.edu.upeu.abspolimorfismo;

public class Loro extends Animal {

    @Override
    void emitirSonido() {
        System.out.println("Hey...no te distraigas!");

    }

    @Override
    void dormir() {
        System.out.println("Dejeme dormir...zzz.zzz.zz..");
    }

}
