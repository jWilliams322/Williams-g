package pe.edu.upeu.encapsulaminto;

import lombok.*;
@NoArgsConstructor
@AllArgsConstructor
@Data

public class Trabajador {
    private String nombre;
    private int edad;
    private String apellido;
    private String area;
    private char genero;


    @Override
    public String toString() {
        return  "Tiene las siguientes caracteristcias:\n" +
                "Nombre:"+nombre+"\n"+
                "Apellido:"+apellido+"\n";


    }
}
