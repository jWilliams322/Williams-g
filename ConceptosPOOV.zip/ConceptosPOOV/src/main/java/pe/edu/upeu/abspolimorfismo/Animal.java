package pe.edu.upeu.abspolimorfismo;

public abstract class Animal {
   abstract void emitirSonido();

   void dormir(){
       System.out.println("Zzzz....Zzz ..Zz..");
   }
}
