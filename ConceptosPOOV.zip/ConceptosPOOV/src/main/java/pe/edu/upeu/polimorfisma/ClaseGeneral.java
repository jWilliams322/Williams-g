package pe.edu.upeu.polimorfisma;

public class ClaseGeneral {
    public static void main(String[] args) {
         Gato g=new Gato();
         g.sonidoAnimal();

         Loro l=new Loro();
         l.sonidoAnimal();
    }
}
