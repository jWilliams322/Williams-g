package pe.edu.upeu.polimorfisma;

public class Loro extends Animal {

    @Override
    void sonidoAnimal() {
        System.out.println("Not te entiendo porque sigues jugando");
    }
}
