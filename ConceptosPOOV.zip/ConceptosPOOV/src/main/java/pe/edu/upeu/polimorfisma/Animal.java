package pe.edu.upeu.polimorfisma;

public class Animal {
    void sonidoAnimal(){
        System.out.println("El animal hace sonido");

    }

}
