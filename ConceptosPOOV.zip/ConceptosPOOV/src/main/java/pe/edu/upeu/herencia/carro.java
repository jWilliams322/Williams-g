package pe.edu.upeu.herencia;

public class carro extends vehiculo{

        public static void main(String[] args){
            carro c = new carro();
            System.out.println("Caracteristicas:");
            c.marca="Toyota";
            System.out.println("Marca:"+c.marca);
            System.out.println("Modelo:"+c.modelo);
            System.out.println("Coloro:"+"No se puede heredar por ser privado");
            c.sonido();
        }
}
