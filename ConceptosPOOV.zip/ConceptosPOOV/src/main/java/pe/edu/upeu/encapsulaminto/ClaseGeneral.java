package pe.edu.upeu.encapsulaminto;

public class ClaseGeneral {

    public static void main(String[] args) {
        persona p = new persona();// p=objeto
        // p.nombre="Ruben";
        //p.edad=20;
        p.setNombre("Ruben");
        p.setEdad(20);
        p.apellido = "mamani";
        p.saludo();

        persona p2 = new persona();


        Trabajador t=new Trabajador();
        t.setNombre("Ruben");
        t.setApellido("Mamani");
        t.setEdad(20);
        t.setArea("sistemas");
        t.setGenero('M');
        System.out.println();


    }
}
