package pe.edu.upeu.herencia;

public class vehiculo {
    String marca="Ford";
    protected String modelo="Fiesta";
    private String color="Red";

    public void sonido(){
        System.out.println("tuut ... tuut. ");
    }
}
